#include <stdlib.h>

/*
 * Somente serve para Tempo ;'(
 */

/* Calcula um número aleatório entre x e y */
int aleat(int x, int y);
/* Gera seed para rand */
int start_seed();