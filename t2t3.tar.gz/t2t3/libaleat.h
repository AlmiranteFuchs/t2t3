#include <stdlib.h>
#include <time.h>

/*
 * Somente serve para Tempo ;'(
 */

/* Calcula um número aleatório entre x e y */
int aleat(int x, int y);
/* Gera seed para rand */
void start_seed();